CREATE DATABASE clinica_veterinaria;
USE clinica_veterinaria;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    usuario VARCHAR(50),
    senha VARCHAR(255)
);

CREATE TABLE tutores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cpf VARCHAR(255),
    telefone VARCHAR(20),
    email VARCHAR(100)
);

CREATE TABLE pets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    raca VARCHAR(100),
    data_nascimento date,
    tutor_id int,
    FOREIGN KEY (tutor_id) REFERENCES tutores(id)
);

CREATE TABLE agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data_agendamento DATE,
    horario TIME,
    motivo VARCHAR(255),
    tutor_id INT,
    pet_id INT,
    FOREIGN KEY (tutor_id) REFERENCES tutores(id),
    FOREIGN KEY (pet_id) REFERENCES pets(id)
);

INSERT INTO usuarios (nome, usuario, senha) VALUES
('Administrador', 'admin', '1234'),
('Maria Silva', 'maria', '1234'),
('João Santos', 'joao', '1234');

INSERT INTO tutores (nome, cpf, telefone, email) VALUES
('Ana Souza', '11111111111', '64999990001', 'ana@email.com'),
('Carlos Oliveira', '22222222222', '64999990002', 'carlos@email.com'),
('Fernanda Lima', '33333333333', '64999990003', 'fernanda@email.com');

INSERT INTO pets (nome, raca, data_nascimento, tutor_id) VALUES
('Mel', 'Shih-tzu', '2021-05-10', 1),
('Thor', 'Labrador', '2020-08-15', 2),
('Luna', 'Poodle', '2022-03-20', 3);

INSERT INTO agendamentos (data_agendamento, horario, motivo, tutor_id, pet_id) VALUES
('2026-10-10', '09:00:00', 'Consulta de rotina', 1, 1),
('2026-10-15', '14:00:00', 'Vacinação', 2, 2),
('2026-11-05', '10:30:00', 'Consulta', 3, 3);