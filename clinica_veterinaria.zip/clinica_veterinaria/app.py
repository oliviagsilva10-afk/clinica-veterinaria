from flask import Flask, render_template, request, redirect, session
import mysql.connector
from cryptography.fernet import Fernet
from datetime import timedelta
import os

app = Flask(__name__)
app.secret_key = "chave-clinica"
app.permanent_session_lifetime = timedelta(minutes=30)

if os.path.exists("chave.key"):
    with open("chave.key", "rb") as arquivo:
        chave = arquivo.read()
else:
    chave = Fernet.generate_key()
    with open("chave.key", "wb") as arquivo:
        arquivo.write(chave)

fernet = Fernet(chave)


def conectar():
    return mysql.connector.connect(
        host="localhost",
        port=3307,
        user="root",
        password="admin",
        database="clinica_veterinaria"
    )


def atualizar_cpfs():
    banco = conectar()
    cursor = banco.cursor(dictionary=True)

    cursor.execute("SELECT id, cpf FROM tutores")
    tutores = cursor.fetchall()

    for tutor in tutores:
        try:
            fernet.decrypt(tutor["cpf"].encode())
        except:
            cpf = fernet.encrypt(tutor["cpf"].encode()).decode()
            cursor.execute(
                "UPDATE tutores SET cpf=%s WHERE id=%s",
                (cpf, tutor["id"])
            )

    banco.commit()
    cursor.close()
    banco.close()


atualizar_cpfs()


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form["usuario"]
        senha = request.form["senha"]

        banco = conectar()
        cursor = banco.cursor(dictionary=True)

        cursor.execute(
            "SELECT * FROM usuarios WHERE usuario=%s AND senha=%s",
            (usuario, senha)
        )

        user = cursor.fetchone()
        cursor.close()
        banco.close()

        if user:
            session.permanent = True
            session["usuario"] = user["nome"]
            return redirect("/inicio")

        return render_template(
            "login.html",
            erro="Usuário ou senha incorretos."
        )

    return render_template("login.html")


@app.route("/inicio")
def inicio():
    if "usuario" not in session:
        return redirect("/")

    return render_template(
        "index.html",
        usuario=session["usuario"]
    )


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


@app.route("/tutores")
def tutores():
    if "usuario" not in session:
        return redirect("/")

    busca = request.args.get("busca", "")

    banco = conectar()
    cursor = banco.cursor(dictionary=True)

    cursor.execute(
        "SELECT * FROM tutores WHERE nome LIKE %s ORDER BY nome",
        ("%" + busca + "%",)
    )

    dados = cursor.fetchall()

    for tutor in dados:
        tutor["cpf"] = fernet.decrypt(
            tutor["cpf"].encode()
        ).decode()

    cursor.close()
    banco.close()

    return render_template("tutores.html", tutores=dados)


@app.route("/tutores/novo", methods=["GET", "POST"])
def novo_tutor():
    if "usuario" not in session:
        return redirect("/")

    if request.method == "POST":
        nome = request.form["nome"]
        cpf = request.form["cpf"]
        telefone = request.form["telefone"]
        email = request.form["email"]

        cpf = fernet.encrypt(cpf.encode()).decode()

        banco = conectar()
        cursor = banco.cursor()

        cursor.execute(
            """INSERT INTO tutores
            (nome, cpf, telefone, email)
            VALUES (%s, %s, %s, %s)""",
            (nome, cpf, telefone, email)
        )

        banco.commit()
        cursor.close()
        banco.close()

        return redirect("/tutores")

    return render_template("novo_tutor.html")


@app.route("/tutores/editar/<int:id>", methods=["GET", "POST"])
def editar_tutor(id):
    if "usuario" not in session:
        return redirect("/")

    banco = conectar()
    cursor = banco.cursor(dictionary=True)

    if request.method == "POST":
        nome = request.form["nome"]
        cpf = request.form["cpf"]
        telefone = request.form["telefone"]
        email = request.form["email"]

        cpf = fernet.encrypt(cpf.encode()).decode()

        cursor.execute(
            """UPDATE tutores
            SET nome=%s, cpf=%s, telefone=%s, email=%s
            WHERE id=%s""",
            (nome, cpf, telefone, email, id)
        )

        banco.commit()
        cursor.close()
        banco.close()

        return redirect("/tutores")

    cursor.execute(
        "SELECT * FROM tutores WHERE id=%s",
        (id,)
    )

    tutor = cursor.fetchone()
    tutor["cpf"] = fernet.decrypt(
        tutor["cpf"].encode()
    ).decode()

    cursor.close()
    banco.close()

    return render_template(
        "editar_tutor.html",
        tutor=tutor
    )


@app.route("/tutores/excluir/<int:id>")
def excluir_tutor(id):
    if "usuario" not in session:
        return redirect("/")

    banco = conectar()
    cursor = banco.cursor()

    cursor.execute(
        "DELETE FROM tutores WHERE id=%s",
        (id,)
    )

    banco.commit()
    cursor.close()
    banco.close()

    return redirect("/tutores")


@app.route("/pets")
def pets():
    if "usuario" not in session:
        return redirect("/")

    banco = conectar()
    cursor = banco.cursor(dictionary=True)

    cursor.execute("""
        SELECT pets.*, tutores.nome AS tutor
        FROM pets
        JOIN tutores ON pets.tutor_id = tutores.id
        ORDER BY pets.nome
    """)

    dados = cursor.fetchall()

    cursor.close()
    banco.close()

    return render_template(
        "pets.html",
        pets=dados
    )


@app.route("/pets/novo", methods=["GET", "POST"])
def novo_pet():
    if "usuario" not in session:
        return redirect("/")

    banco = conectar()
    cursor = banco.cursor(dictionary=True)

    if request.method == "POST":
        nome = request.form["nome"]
        raca = request.form["raca"]
        data_nascimento = request.form["data_nascimento"]
        tutor_id = request.form["tutor_id"]

        cursor.execute(
            """INSERT INTO pets
            (nome, raca, data_nascimento, tutor_id)
            VALUES (%s, %s, %s, %s)""",
            (nome, raca, data_nascimento, tutor_id)
        )

        banco.commit()
        cursor.close()
        banco.close()

        return redirect("/pets")

    cursor.execute(
        "SELECT id, nome FROM tutores ORDER BY nome"
    )

    tutores = cursor.fetchall()

    cursor.close()
    banco.close()

    return render_template(
        "novo_pet.html",
        tutores=tutores
    )


@app.route("/agendamentos")
def agendamentos():
    if "usuario" not in session:
        return redirect("/")

    banco = conectar()
    cursor = banco.cursor(dictionary=True)

    cursor.execute("""
        SELECT agendamentos.*,
               tutores.nome AS tutor,
               pets.nome AS pet
        FROM agendamentos
        JOIN tutores ON agendamentos.tutor_id = tutores.id
        JOIN pets ON agendamentos.pet_id = pets.id
        ORDER BY MONTH(data_agendamento),
                 data_agendamento,
                 horario
    """)

    dados = cursor.fetchall()

    cursor.close()
    banco.close()

    return render_template(
        "agendamentos.html",
        agendamentos=dados
    )


@app.route("/agendamentos/novo", methods=["GET", "POST"])
def novo_agendamento():
    if "usuario" not in session:
        return redirect("/")

    banco = conectar()
    cursor = banco.cursor(dictionary=True)

    if request.method == "POST":
        data = request.form["data_agendamento"]
        horario = request.form["horario"]
        motivo = request.form["motivo"]
        tutor_id = request.form["tutor_id"]
        pet_id = request.form["pet_id"]

        cursor.execute(
            """INSERT INTO agendamentos
            (data_agendamento, horario, motivo, tutor_id, pet_id)
            VALUES (%s, %s, %s, %s, %s)""",
            (data, horario, motivo, tutor_id, pet_id)
        )

        banco.commit()
        cursor.close()
        banco.close()

        return redirect("/agendamentos")

    cursor.execute(
        "SELECT id, nome FROM tutores ORDER BY nome"
    )
    tutores = cursor.fetchall()

    cursor.execute(
        "SELECT id, nome, tutor_id FROM pets ORDER BY nome"
    )
    pets = cursor.fetchall()

    cursor.close()
    banco.close()

    return render_template(
        "novo_agendamento.html",
        tutores=tutores,
        pets=pets
    )


if __name__ == "__main__":
    app.run(debug=True)